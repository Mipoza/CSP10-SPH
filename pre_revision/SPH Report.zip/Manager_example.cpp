template<unsigned int Dim>
class Manager: public BaseManager {
public:
    using particle_position_type  = ParticleAttrib<Vector<double, Dim>>;
    using particle_scalar_type  = ParticleAttrib<double>;

    SPHParticle<double, Dim> particles;
    double dt;
    double Adiabatic_index;
    double h;
    std::array<ippl::BC,2*Dim>  bcs;
    ippl::Vector<double, Dim> L_, low_;

    Manager(ParticleSpatialLayout<double,Dim>& L, ippl::Vector<double,Dim>& low,
    ippl::Vector<double,Dim>& extent, double dt_, double h_, double Adiabatic_index_) : 
    dt(dt_), h(h_), particles(L, low, extent, h_), Adiabatic_index(Adiabatic_index_), L_(extent), low_(low) {}